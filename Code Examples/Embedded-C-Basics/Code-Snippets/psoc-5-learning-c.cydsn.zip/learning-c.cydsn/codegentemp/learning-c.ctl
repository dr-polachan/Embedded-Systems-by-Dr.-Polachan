-- ======================================================================
-- learning-c.ctl generated from learning-c
-- 07/09/2026 at 11:55
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor

# Component constraints for C:\Users\kuria\OneDrive\Desktop\psoc-5lp-c-book\learning-c.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\kuria\OneDrive\Desktop\psoc-5lp-c-book\learning-c.cydsn\learning-c.cyprj
# Date: Thu, 09 Jul 2026 06:25:51 GMT

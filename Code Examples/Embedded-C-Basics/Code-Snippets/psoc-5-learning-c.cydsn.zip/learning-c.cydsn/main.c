
// main.c
#include <stdio.h>
#include "hal.h"
#include "mathlib.h"

int main(void)
{
    char txBuf[50];         
    
    HAL_Init();
    HAL_UART_Init();
          
    uint8_t index = 0;
    
    while(index < 5)
    {               
        snprintf(txBuf, sizeof(txBuf), "Hello World ! \r\n");
        HAL_UART_Write(txBuf);
        
        index = index + 1;
    }
}
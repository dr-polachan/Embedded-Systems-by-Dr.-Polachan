/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "hal.h"
#include "project.h"

void HAL_Init(void)
{
    CyGlobalIntEnable;
}

void HAL_UART_Init(void)
{
    UART_Start();
}

void HAL_UART_Write(const char *str)
{
    UART_PutString(str);
}
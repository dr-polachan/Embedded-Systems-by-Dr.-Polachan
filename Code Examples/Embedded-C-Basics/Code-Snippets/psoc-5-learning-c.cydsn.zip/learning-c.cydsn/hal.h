/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// hal.h
#ifndef HAL_H
#define HAL_H

void HAL_Init(void);
void HAL_UART_Init(void);
void HAL_UART_Write(const char *str);


#endif
